import json

def parse_annotation(annotation_list):
    """주석 리스트를 고유한 문자열 집합으로 변환합니다.
    예: [["시스템#진입장벽", "negative"]] -> {"시스템#진입장벽__negative"}
    """
    return {f"{anno[0]}__{anno[1]}" for anno in annotation_list if len(anno) == 2}

def load_data(filepath, limit=996):
    """파일에서 상위 N개의 데이터를 {id: 주석집합} 형태로 로드합니다."""
    data = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            item = json.loads(line)
            review_id = item['id']
            data[review_id] = parse_annotation(item['annotation'])
            if len(data) >= limit:
                break
    return data

def compute_krippendorff_alpha_binary(matrix):
    """명목형(Nominal) 이진 데이터에 대한 크리펜도르프 알파를 직접 계산합니다.
    matrix: N x R 형태의 2차원 리스트 (값은 0 또는 1)
    """
    N = len(matrix)
    R = len(matrix[0])
    n = N * R
    
    # 1. 관측된 불일치 (Do) 계산
    total_do_sum = 0
    for row in matrix:
        n_0 = row.count(0)
        n_1 = row.count(1)
        total_do_sum += 2 * n_0 * n_1
    Do = total_do_sum / (N * R * (R - 1))
    
    # 2. 우연에 의한 기대 불일치 (De) 계산
    P_0 = sum(row.count(0) for row in matrix)
    P_1 = sum(row.count(1) for row in matrix)
    De = (2 * P_0 * P_1) / (n * (n - 1))
    
    if De == 0:
        return 1.0 if Do == 0 else 0.0
    
    return 1 - (Do / De)

# ==========================================
# 1. 데이터 로드 및 전처리
# ==========================================
base_file = "steam_reviews_pre_labeled_GPT.jsonl"
claude_file = "steam_reviews_pre_labeled_claude.jsonl"
gemini_file = "steam_reviews_pre_labeled_gemini.jsonl"

base_data = load_data(base_file, limit=996)
claude_data = load_data(claude_file, limit=996)
gemini_data = load_data(gemini_file, limit=996)

# 996개 샘플 내에서 원본 및 LLM들이 단 한 번이라도 사용한 모든 유니크 레이블 수집
all_labels = set()
for r_id in base_data:
    all_labels.update(base_data[r_id])
    if r_id in claude_data: all_labels.update(claude_data[r_id])
    if r_id in gemini_data: all_labels.update(gemini_data[r_id])
all_labels = sorted(list(all_labels))

print(f"분석 대상 유니크 레이블 수: {len(all_labels)}개")

# ==========================================
# 2. 신뢰도 행렬(Reliability Matrix) 구축
# ==========================================
matrix_all = []     # 삼자 비교 (Base, Claude, Gemini)
matrix_claude = []  # 양자 비교 (Base vs Claude)
matrix_gemini = []  # 양자 비교 (Base vs Gemini)

for r_id in base_data:
    # 안전한 매칭을 위해 세 파일 모두에 ID가 존재하는 경우만 연산
    if r_id not in claude_data or r_id not in gemini_data:
        continue
        
    for label in all_labels:
        b_val = 1 if label in base_data[r_id] else 0
        c_val = 1 if label in claude_data[r_id] else 0
        g_val = 1 if label in gemini_data[r_id] else 0
        
        matrix_all.append([b_val, c_val, g_val])
        matrix_claude.append([b_val, c_val])
        matrix_gemini.append([b_val, g_val])

# ==========================================
# 3. 크리펜도르프 알파 산출
# ==========================================
alpha_all = compute_krippendorff_alpha_binary(matrix_all)
alpha_claude = compute_krippendorff_alpha_binary(matrix_claude)
alpha_gemini = compute_krippendorff_alpha_binary(matrix_gemini)

print("\n=== Krippendorff's Alpha 결과 ===")
print(f"전체 종합 (Base + Claude + Gemini) Alpha : {alpha_all:.4f}")
print(f"원본 vs Claude 양자 간 일치도 Alpha      : {alpha_claude:.4f}")
print(f"원본 vs Gemini 양자 간 일치도 Alpha      : {alpha_gemini:.4f}")